import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import App from './App';
import reportWebVitals from './reportWebVitals';
import Header from './Header.js';
import Footer from './Footer.js';
import Playlist from './Playlist.js';
import Discogs from './Discogs.js';


class Page extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
          addedToFavourites: false
        }
      }
    onAddedToFavourites(isAdded, playListCount) {
        this.setState({
          addedToFavourites: isAdded
        })
        window.location.reload(false);
      }
    render(){
        const { addedToFavourites } = this.state;

              return (
              <div>
                  <Header companyName="Discogs.com"/>

                   <Playlist addedToFavourites={addedToFavourites}/>
                   <Discogs onAddedToFavourites={(isAdded) => { this.onAddedToFavourites(isAdded) }} />
                   <Footer authorName="Janki Jariwala and Parth Amin"/>

              </div>
          )
      }
  }



  ReactDOM.render(<Page/>,document.getElementById('root'));

reportWebVitals();
